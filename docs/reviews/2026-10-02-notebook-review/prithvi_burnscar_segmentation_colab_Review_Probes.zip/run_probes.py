"""Probes for the Notebook Review Framework v1 review of tutorials/prithvi_burnscar_segmentation_colab.ipynb
(prithvi-burnscar-segmentation-pipeline @ 7361e2823c1ee02f7777934b2ddd9e958132f237).

CPU-only (CUDA_VISIBLE_DEVICES=-1), no model weights, no terratorch, no network. Synthetic 512x512 chips and a tiny
stub torch model stand in for the real scenes and the Prithvi model; every result is labelled with that basis.
Usage: python run_probes.py <repo_worktree> [<kaggle_evidence_dir>]
"""
from __future__ import annotations

import ast
import io
import json
import os
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile
from pathlib import Path
from types import SimpleNamespace

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
REPO = Path(sys.argv[1]).resolve()
EVID = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else None
NB = REPO / "tutorials" / "prithvi_burnscar_segmentation_colab.ipynb"
sys.path.insert(0, str(REPO / "src"))
sys.path.insert(0, str(REPO / "tests"))
results: dict = {"repo": str(REPO), "basis_default": "direct execution, local Windows CPU, synthetic stand-ins"}


def probe(name):
    def deco(fn):
        t0 = time.perf_counter()
        try:
            value = fn()
        except Exception as exc:  # record, keep going
            value = {"probe_error": f"{type(exc).__name__}: {exc}", "trace": traceback.format_exc()[-800:]}
        value["seconds"] = round(time.perf_counter() - t0, 2)
        results[name] = value
        return fn
    return deco


def run(cmd, timeout=500):
    p = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True, timeout=timeout,
                       env={**os.environ, "PYTHONPATH": str(REPO / "src")})
    return {"cmd": " ".join(cmd[1:]), "returncode": p.returncode, "tail": (p.stdout + p.stderr)[-600:]}


@probe("P1_static_notebook")
def _p1():
    nb = json.loads(NB.read_text(encoding="utf-8"))
    code = [(i, "".join(c["source"])) for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"]
    for i, src in code:
        compile(src, f"cell{i}", "exec")
    md = "\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown")
    words = ["How to use", "Glossary", "Troubleshoot", "Infrastructure", "Expected result", "What to notice",
             "Check your reasoning", "Look for", "audience", "threshold"]
    return {"cells": len(nb["cells"]), "code_cells": len(code), "code_cells_compile": True,
            "metadata_dimer": nb["metadata"]["dimer"],
            "carried_module_lines": sum(len(s.splitlines()) for i, s in code if i in (5, 7, 9)),
            "code_cell_cellView": [nb["cells"][i]["metadata"].get("cellView") for i, _ in code],
            "markdown_markers_present": {w: (w.lower() in md.lower()) for w in words},
            "brace_typo_present": "{{id, image, label}}" in md,
            "image_display_calls": sum(("imshow" in s or "display(" in s or "plt." in s) for _, s in code)}


@probe("P2_offline_checks")
def _p2():
    return {"build_check": run([sys.executable, "tools/build_notebook.py", "--check"]),
            "validator": run([sys.executable, "tools/validate_release_assets.py"]),
            "pytest": run([sys.executable, "-m", "pytest", "-q", "-o", "addopts=", "tests", "-p", "no:cacheprovider"])}


def _sample_records():
    tree = ast.parse((REPO / "src/prithvi_burnscar_segmentation_pipeline/samples.py").read_text(encoding="utf-8"))
    for n in tree.body:
        if isinstance(n, ast.AnnAssign) and getattr(n.target, "id", "") == "SAMPLE_RECORDS":
            return ast.literal_eval(n.value)
    raise RuntimeError("SAMPLE_RECORDS not found")


@probe("P3_sample_split_and_example_overlap")
def _p3():
    recs = _sample_records()
    tiles: dict = {}
    for r in recs:
        tiles.setdefault(r[1], set()).add(r[0].split(".")[0])
    manifest = json.loads((REPO / "weights/prithvi-eo-2.0-300m-burnscars/dimer-base-manifest.json").read_text(encoding="utf-8"))
    examples = [f for f in manifest["files"] if f["path"].startswith("examples/")]
    split_files = {s: (REPO / f"weights/prithvi-eo-2.0-300m-burnscars/splits/{s}.txt").read_text().split()
                   for s in ("train", "val", "test")}
    ex = []
    for f in examples:
        key = f["path"].split("HLS.S30.")[1].replace(".4_merged.tif", "")
        ex.append({"example": key, "upstream_split": [s for s, v in split_files.items() if key in v],
                   "byte_identical_to_sample_record": [r[0] + "/" + r[1] for r in recs if r[4] == f["sha256"]],
                   "in_sample_train": any(r[0] == key and r[1] == "train" for r in recs)})
    overlap = sorted(tiles["train"] & tiles["test"])
    return {"tiles_per_role": {k: len(v) for k, v in tiles.items()}, "train_test_shared_tiles": overlap,
            "shared_tile_scenes": [r[0] + "/" + r[1] for r in recs if r[0].split(".")[0] in overlap],
            "train_val_shared": sorted(tiles["train"] & tiles["validation"]), "examples": ex}


def _tif(arr):
    import tifffile
    b = io.BytesIO()
    kw = {"planarconfig": "separate"} if arr.ndim == 3 else {}
    tifffile.imwrite(b, arr, photometric="minisblack", **kw)
    return b.getvalue()


def _zip(path, n, *, bands=6, label_value=None, drop_csv=False, missing_member=False, bad_image=False, no_burn=False):
    import numpy as np
    from conftest import synthetic_chip
    with zipfile.ZipFile(path, "w") as z:
        rows = ["id,image,label"]
        for i in range(n):
            img, lab = synthetic_chip(seed=i, bands=bands)
            if label_value is not None and i == 0:
                lab = np.where(lab == 1, label_value, lab)
            if no_burn:
                lab = np.zeros_like(lab)
            rows.append(f"c{i},c{i}.tif,c{i}_mask.tif")
            if missing_member and i == 0:
                continue
            z.writestr(f"c{i}.tif", b"not a tiff" if (bad_image and i == 0) else _tif(img.astype("float32")))
            z.writestr(f"c{i}_mask.tif", _tif(lab.astype("int16")))
        if not drop_csv:
            z.writestr("pairs.csv", "\n".join(rows) + "\n")
    return path


@probe("P4_byod_loader_and_split")
def _p4():
    from prithvi_burnscar_segmentation_pipeline import load_byod_dataset, split_dataset
    out = {"basis": "direct execution of the carried load_byod_dataset + split_dataset(seed=0) as Section 4 calls them, synthetic zips"}
    tmp = Path(tempfile.mkdtemp())

    def attempt(label, path):
        try:
            s = split_dataset(load_byod_dataset(path), seed=0)
            out[label] = {"ok": True, "splits": {k: len(v) for k, v in s.items()}}
        except Exception as exc:
            out[label] = {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:200]}"}

    for n in (4, 5, 6, 7):
        attempt(f"valid_n{n}", _zip(tmp / f"n{n}.zip", n))
    attempt("five_band_chip", _zip(tmp / "b5.zip", 8, bands=5))
    attempt("label_value_2", _zip(tmp / "l2.zip", 8, label_value=2))
    attempt("no_burn_pixels", _zip(tmp / "nb.zip", 8, no_burn=True))
    attempt("no_pairs_csv", _zip(tmp / "nocsv.zip", 8, drop_csv=True))
    attempt("csv_names_missing_member", _zip(tmp / "miss.zip", 8, missing_member=True))
    attempt("non_tiff_image", _zip(tmp / "bad.zip", 8, bad_image=True))
    (tmp / "x.csv").write_text("id,image,label\n")
    attempt("non_zip_upload", tmp / "x.csv")
    return out


@probe("P5_exported_pairs_csv_names")
def _p5():
    """Section 4 writes outputs/..._sample_pairs.csv 'in the shape BYOD expects'; do its file names match any file the
    notebook writes or extracts?"""
    from prithvi_burnscar_segmentation_pipeline import write_dataset_csv
    recs = [r for r in _sample_records() if r[1] == "test"]
    test = [{"id": f"test-{i:03d}", "source_id": r[0], "region": r[0].split(".")[0], "source": "x"} for i, r in enumerate(recs)]
    tmp = Path(tempfile.mkdtemp())
    p = write_dataset_csv(test, tmp / "pairs.csv")
    rows = p.read_text(encoding="utf-8").splitlines()[1:3]
    extracted = {Path(r[2]).name for r in _sample_records()} | {Path(r[5]).name for r in _sample_records()}
    written = {"prithvi_burnscar_segmentation_sample_chip.tif", "prithvi_burnscar_segmentation_sample_label.tif"}
    named = [(row.split(",")[1], row.split(",")[2]) for row in rows]
    return {"csv_rows_head": rows, "image_names_match_extracted_chips": all(a in extracted for a, _ in named),
            "label_names_match_extracted_masks": all(b in extracted for _, b in named),
            "names_match_written_sample_pair": all(a in written for a, _ in named),
            "extracted_name_examples": sorted(extracted)[:2]}


@probe("P6_adapt_rerun_epoch0_label")
def _p6():
    """adapt() trains from the model's current state: does a second call (BYOD rerun from Section 4 or an optional
    experiment rerunning Section 6) still label epoch 0 'frozen model'? Stub torch model, CPU, synthetic chips."""
    import torch
    from conftest import synthetic_records
    from prithvi_burnscar_segmentation_pipeline import PrithviBurnScarPipeline

    class Stub(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.neck = torch.nn.Module()
            self.neck.scale = torch.nn.Parameter(torch.ones(1))
            self.decoder = torch.nn.Module()
            self.decoder.weight = torch.nn.Parameter(torch.zeros(6))
            self.head = torch.nn.Module()
            self.head.bias = torch.nn.Parameter(torch.zeros(2))

        def forward(self, x):
            f = (x * self.decoder.weight[None, :, None, None]).sum(1) * self.neck.scale
            return SimpleNamespace(output=torch.stack([-f + self.head.bias[0], f + self.head.bias[1]], 1))

    torch.set_num_threads(2)
    pipe = PrithviBurnScarPipeline(model=Stub(), device="cpu", weights_dir=Path("unused"), source="stub")
    train, val, test = synthetic_records(4, seed=0), synthetic_records(2, seed=10), synthetic_records(2, seed=20)
    frozen_test = pipe.evaluate(test)["model"]["iou"]["burn scar"]
    first = pipe.adapt(train, val, epochs=3, lr=1e-2)
    section5_rerun = pipe.evaluate(test)["model"]["iou"]["burn scar"]
    second = pipe.adapt(train, val, epochs=1, lr=1e-2)
    h1, h2 = first["history"], second["history"]
    kept = h1[first["best_epoch"]]["val_loss"]
    return {"first_epoch0_val_loss": h1[0]["val_loss"], "first_best_epoch": first["best_epoch"], "first_kept_val_loss": kept,
            "second_epoch0_note": h2[0].get("note"), "second_epoch0_val_loss": h2[0]["val_loss"],
            "second_epoch0_equals_first_kept": abs(h2[0]["val_loss"] - kept) < 1e-6,
            "second_epoch0_equals_true_frozen": abs(h2[0]["val_loss"] - h1[0]["val_loss"]) < 1e-6,
            "test_burn_iou_true_frozen": frozen_test, "test_burn_iou_section5_rerun_after_adapt": section5_rerun}


@probe("P7_documented_execution_evidence")
def _p7():
    if EVID is None or not (EVID / "run_summary.json").is_file():
        return {"available": False}
    s = json.loads((EVID / "run_summary.json").read_text(encoding="utf-8"))
    p1 = json.loads((EVID / "executed-pass1.ipynb").read_text(encoding="utf-8"))
    errs = [(i, o["ename"], o["evalue"][:300]) for i, c in enumerate(p1["cells"])
            for o in c.get("outputs", []) if o.get("output_type") == "error"]
    ex = json.loads((EVID / "executed.ipynb").read_text(encoding="utf-8"))

    def out(i):
        return "".join("".join(o.get("text", "")) for o in ex["cells"][i].get("outputs", []) if o.get("output_type") == "stream")

    def secs(c):
        f = "%Y-%m-%dT%H:%M:%S"
        return round(time.mktime(time.strptime(c["ended"][:19], f)) - time.mktime(time.strptime(c["started"][:19], f)))

    return {"basis": "documented execution evidence (Kaggle T4 2026-09-25, workspace archive)",
            "identity": {k: s["identity"][k] for k in ("candidate_sha", "committed_blob", "fetched_blob_verified", "image_versions_before_run")},
            "passes": [{k: p.get(k) for k in ("attempt", "ok", "started")} for p in s["runner"]["passes"]],
            "pass1_errors": errs, "pass2_cell_seconds": {c["cell"]: secs(c) for c in s["cells"]},
            "section7_comparison": [ln for ln in out(19).splitlines() if ln.startswith("{'")][:6],
            "section8_examples": [ln for ln in out(21).splitlines() if "sanity" in ln],
            "section5_T10SEH": [ln for ln in out(15).splitlines() if "T10SEH" in ln]}


Path("results.json").write_text(json.dumps(results, indent=1, default=str), encoding="utf-8")
for k, v in results.items():
    print(k, json.dumps(v, default=str)[:1600])
